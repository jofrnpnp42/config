unite-w3m
=========

unite source for w3m.vim

Requirements
------------
- [w3m.vim](https://github.com/yuratomo/w3m.vim)
- [unite.vim](https://github.com/Shougo/unite.vim)

Usage
-----
### Select search engines

    :Unite w3m

### Select history

    :Unite w3m/history
