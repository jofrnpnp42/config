static const foo = 10;

int
Foo(void)
{
  return 11;
  return 12;
  return 13;
}

  static const bar = 21;

  int
  Bar(void)
  {
    return 21;
    return 22;
    return 23;
  }

static const baz = 31;

int
Baz(void)
{
  return 31;
  return 32;
  return 33;
}

int
QuxSingle(void) {
   return 41;
   return 42;
   return 43;
}

int
QuxMultiple(
    int a,
    char b
) {
   return 51;
   return 52;
   return 53;
}
