# Thank You
The following individuals have contributed to `z` :heart:

* [James Campos](https://github.com/aeosynth)
* [Jethro Kuan](https://github.com/jethrokuan)
* [Jorge Bucaran](https://github.com/bucaran)
* [rupa](https://github.com/rupa) for the original code
* [sjl](https://github.com/sjl) for the original fish port
